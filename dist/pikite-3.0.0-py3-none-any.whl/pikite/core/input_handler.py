class InputHandler:
    pass